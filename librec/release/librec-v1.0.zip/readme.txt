* Version 1.0

* librec.jar is a runnable jar via 
    java -jar librec.jar

* Folder librec_lib contains all depedent libraries. 

* log4j.xml configs the logger for librec.jar

* librec.conf configs the recommender for librec.jar
  to understand the configurations, see http://trust.sce.ntu.edu.sg/~gguo1/librec/tutorial.html#config

* ml100k.txt: MovieLens 100K dataset
